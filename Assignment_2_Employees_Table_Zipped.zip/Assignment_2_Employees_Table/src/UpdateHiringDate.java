// Import of packages
import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;
import javax.swing.JTextField;

public class UpdateHiringDate extends JFrame {
	// Declaration of variables
	private JPanel panel;
	private JTextArea employeeListTa; // Where the records will be shown
	private JButton searchBtn, updateBtn;
	private JScrollPane scrollPane; // A scroll pane
	private JScrollBar scrollBar;
	private JLabel updateHiringDateLbl, updateEmploymentDateLbl, employeeIdLbl;
	private JTextField employeeIdTf, updateEmploymentDateTf;
	private Connection myConn;
	private PreparedStatement pStmt;
	private ResultSet myRs;
	private final int WINDOW_WIDTH = 300; // Window width
	private final int WINDOW_HEIGHT = 300; // Window height

	public UpdateHiringDate() { // Default constructor

	}

	public UpdateHiringDate(Connection connection) { // Specific constructor that will be called first to pass the
		// active connection and then this connection will be used in the default
		// constructor
		myConn = connection;

		setTitle("Update hiring date"); // Setting the title

		// Setting size of the window
		setSize(WINDOW_WIDTH, WINDOW_HEIGHT);

		// We can see the window
		setVisible(true);

		panel = new JPanel(); // Create an instance of the panel

		// Label that tells user where to input their new hiring date
		updateHiringDateLbl = new JLabel("Update Hiring Date");
		updateHiringDateLbl.setHorizontalAlignment(SwingConstants.CENTER);
		updateHiringDateLbl.setFont(new Font("Tahoma", Font.BOLD, 25));

		// Needs to search records to see what specific employee's hiring date needs
		// changing
		employeeListTa = new JTextArea();
		employeeListTa.setSize(264, 172);
		employeeListTa.setLocation(10, 11);
		employeeListTa.setFont(new Font("Tahoma", Font.PLAIN, 15));
		employeeListTa.setEditable(false); // Do not allow user to type into the text area

		// Add the list to a scroll pane.
		scrollPane = new JScrollPane(employeeListTa);
		scrollBar = new JScrollBar();
		scrollPane.add(scrollBar);
		scrollPane.setSize(264, 77);
		scrollPane.setLocation(10, 47);

		// Search button that will show the list of records that match the EID input by
		// user
		searchBtn = new JButton("Search");
		searchBtn.setLocation(113, 9);
		searchBtn.setSize(161, 29);
		searchBtn.setFont(new Font("Tahoma", Font.PLAIN, 15));
		searchBtn.addActionListener(new ActionListener() {
			// When button is clicked
			public void actionPerformed(ActionEvent e) { // Waits for the action
				String buttonClicked = e.getActionCommand();

				if (buttonClicked.equals("Search")) {
					try {
						// Prepare the SQL statement to insert a new employee
						pStmt = myConn.prepareStatement("SELECT * FROM employee WHERE EID = ?");

						// Set the parameters for the SQL statement
						pStmt.setInt(1, Integer.parseInt(employeeIdTf.getText()));

						// Execute the SQL statement
						myRs = pStmt.executeQuery();

						while (myRs.next()) {
							employeeListTa.append(myRs.getInt("EID") + ", " + myRs.getString("fName") + ", "
									+ myRs.getString("lName") + ", " + myRs.getString("DateOfJoining") + "\n");
						}

						// Close the PreparedStatement
						pStmt.close();
					} catch (SQLException e1) {
					} catch (NumberFormatException e2) {
						JOptionPane.showMessageDialog(null, "You must have an Integer value");
						employeeIdTf.setText("");
					}
				}
			}
		});

		// After the user updates the information for hiring date, this button will
		// serve as the confirmation to change it
		// in the records
		updateBtn = new JButton("Update");
		updateBtn.setBounds(100, 194, 85, 25);
		updateBtn.setFont(new Font("Tahoma", Font.PLAIN, 15));
		updateBtn.addActionListener(new ActionListener() {
			// When button is clicked
			public void actionPerformed(ActionEvent e) { // Waits for the action
				String buttonClicked = e.getActionCommand();

				if (buttonClicked.equals("Update")) {
					
					try {
						// Prepare the SQL statement to insert a new employee
						pStmt = myConn.prepareStatement(
								"UPDATE employee SET DateOfJoining = ?"
								+ "WHERE EID = ?");

						// Set the parameters for the SQL statement
						pStmt.setString(1, updateEmploymentDateTf.getText());	// Database will convert it to a date
						pStmt.setInt(2, Integer.parseInt(employeeIdTf.getText()));

						// Execute the SQL statement
						pStmt.executeUpdate();

						// Close the PreparedStatement
						pStmt.close();
						dispose();
						JOptionPane.showMessageDialog(null, "Hiring date updated");
					} catch (SQLException e1) {
						JOptionPane.showMessageDialog(null, "String input cannot be greater than 45 characters or "
								+ "incorrect date format (yyyy-mm-dd)");
					} catch (NumberFormatException e2) {
						JOptionPane.showMessageDialog(null, "You must fill out the form");
					}

					// Clearing the input to make sure it is not pre-filled
					employeeIdTf.setText("");
					updateEmploymentDateTf.setText("");
					employeeListTa.setText("");

				}
			}
		});
		panel.setLayout(null);

		// EID Label
		employeeIdLbl = new JLabel("EID:");
		employeeIdLbl.setFont(new Font("Tahoma", Font.PLAIN, 15));
		employeeIdLbl.setBounds(10, 14, 29, 19);

		// EID Text field
		employeeIdTf = new JTextField(45);
		employeeIdTf.setBounds(48, 11, 55, 25);
		employeeIdTf.setFont(new Font("Tahoma", Font.PLAIN, 15));

		// Update Hiring Date Label
		updateEmploymentDateLbl = new JLabel("New Hiring Date:");
		updateEmploymentDateLbl.setFont(new Font("Tahoma", Font.PLAIN, 15));
		updateEmploymentDateLbl.setBounds(10, 143, 115, 19);

		updateEmploymentDateTf = new JTextField(45);
		updateEmploymentDateTf.setFont(new Font("Tahoma", Font.PLAIN, 15));
		updateEmploymentDateTf.setBounds(124, 140, 150, 25);

		// Adding all of these components to the panel
		getContentPane().add(updateHiringDateLbl, BorderLayout.NORTH);
		panel.add(employeeIdLbl);
		panel.add(employeeIdTf);
		panel.add(searchBtn);
		panel.add(scrollPane);
		panel.add(updateEmploymentDateLbl);
		panel.add(updateEmploymentDateTf);
		panel.add(updateBtn);
		getContentPane().add(panel); // This adds the panel to the content frame
	}
}
