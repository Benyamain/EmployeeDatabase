// Import of packages
import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;

public class DisplayAllEmployees extends JFrame {
	// Declaration of variables
	private JPanel panel;
	private JTextArea employeeListTa; // Where the records will be shown
	private JButton returnBtn;
	private JScrollPane scrollPane; // A scroll pane
	private JScrollBar scrollBar;
	private JLabel employeeListLbl;
	private Connection myConn;
	private Statement stmt;
	private ResultSet myRs;
	private final int WINDOW_WIDTH = 300; // Window width
	private final int WINDOW_HEIGHT = 300; // Window height

	public DisplayAllEmployees() { // Constructor

	}

	public DisplayAllEmployees(Connection connection) { // Specific constructor that will be called first to pass the
														// active connection and then
		// this connection will be used in the default constructor
		myConn = connection;

		setTitle("Display all employees"); // Setting the title

		// Setting size of the window
		setSize(WINDOW_WIDTH, WINDOW_HEIGHT);

		// We can see the window
		setVisible(true);

		panel = new JPanel(); // Create an instance of the panel

		// Title of the window
		employeeListLbl = new JLabel("Employee List");
		employeeListLbl.setHorizontalAlignment(SwingConstants.CENTER);
		employeeListLbl.setFont(new Font("Tahoma", Font.BOLD, 25));

		// Text area that shows all the employee records
		employeeListTa = new JTextArea();
		employeeListTa.setSize(264, 172);
		employeeListTa.setLocation(10, 11);
		employeeListTa.setFont(new Font("Tahoma", Font.PLAIN, 15));
		employeeListTa.setEditable(false); // Do not allow user to type into the text area

		// Add the list to a scroll pane with a scroll bar
		scrollPane = new JScrollPane(employeeListTa);
		scrollBar = new JScrollBar();
		scrollPane.add(scrollBar);
		scrollPane.setSize(264, 172);
		scrollPane.setLocation(10, 11);

		// Returns to the main menu once user is done looking at the employee records
		returnBtn = new JButton("Return");
		returnBtn.setBounds(100, 194, 85, 25);
		returnBtn.setFont(new Font("Tahoma", Font.PLAIN, 15));
		returnBtn.addActionListener(new ActionListener() {
			// When button is clicked
			public void actionPerformed(ActionEvent e) { // Waits for the action
				String buttonClicked = e.getActionCommand();

				if (buttonClicked.equals("Return")) {
					dispose(); // Get rid of the window
				}
			}
		});
		panel.setLayout(null);

		// Adding all of these components to the panel
		getContentPane().add(employeeListLbl, BorderLayout.NORTH);
		panel.add(scrollPane);
		panel.add(returnBtn);
		getContentPane().add(panel); // This adds the panel to the content frame

		try {
			// Prepare the SQL statement to insert a new employee
			stmt = myConn.createStatement();
			myRs = stmt.executeQuery("SELECT * FROM employee");

			while (myRs.next()) { // Loop through the rows to get the employee records
				employeeListTa.append(myRs.getInt("EID") + ", " + myRs.getString("fName") + ", "
						+ myRs.getString("lName") + ", " + myRs.getString("DateOfJoining") + "\n");
			}

			// Close the ResultSet
			myRs.close();
		} catch (SQLException e) {
		}
	}
}
