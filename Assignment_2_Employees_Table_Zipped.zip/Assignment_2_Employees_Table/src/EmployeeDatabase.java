/* Name of Program: Assignment_2_Employee_Database.java
 * Purpose of Program: Create an Employee table in contact with MySQL
 * Author of Program: B. Yacoob
 */

// Import of packages
import java.sql.*;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.SwingConstants;
import java.awt.Color;
import java.awt.EventQueue;

public class EmployeeDatabase extends JFrame {
	// Declaration of variables
	private JButton addEmployeeBtn, dropEmployeeBtn, updateDateBtn, countEmployeeBtn, displayEmployeeBtn, exitEmployeeBtn;
	private JPanel panel;
	private JLabel mainMenu;
	private Statement stmt;
	private ResultSet myRs;
	private String results;
	private static Connection myConn = null;
	private final int WINDOW_WIDTH = 450; // Window width
	private final int WINDOW_HEIGHT = 300; // Window height

	public EmployeeDatabase() { // Constructor

		setTitle("Employee Database"); // Setting the title

		// Setting size of the window
		setSize(WINDOW_WIDTH, WINDOW_HEIGHT);

		// What happens when close button is clicked
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		panel = new JPanel(); // Create an instance of the panel
		panel.setLayout(null);

		// Title of the window
		mainMenu = new JLabel("Main Menu");
		mainMenu.setHorizontalAlignment(SwingConstants.CENTER);
		mainMenu.setForeground(new Color(0, 0, 0));
		mainMenu.setFont(new Font("Tahoma", Font.BOLD, 25));

		// Once user clicks the add button, they will be redirected to the appropriate
		// page
		addEmployeeBtn = new JButton("Add an employee");
		addEmployeeBtn.setBounds(30, 29, 177, 33);
		addEmployeeBtn.setFont(new Font("Tahoma", Font.PLAIN, 15));
		addEmployeeBtn.addActionListener(new ButtonListener());

		// Once user clicks the drop button, they will be redirected to the appropriate
		// page
		dropEmployeeBtn = new JButton("Drop an employee");
		dropEmployeeBtn.setBounds(217, 29, 177, 33);
		dropEmployeeBtn.setFont(new Font("Tahoma", Font.PLAIN, 15));
		dropEmployeeBtn.addActionListener(new ButtonListener());

		// Once user clicks the update button, they will be redirected to the
		// appropriate page
		updateDateBtn = new JButton("Update hiring date");
		updateDateBtn.setFont(new Font("Tahoma", Font.PLAIN, 15));
		updateDateBtn.setBounds(30, 84, 177, 33);
		updateDateBtn.addActionListener(new ButtonListener());

		// Once user clicks the count button, they will be given a message
		countEmployeeBtn = new JButton("Count employees");
		countEmployeeBtn.setFont(new Font("Tahoma", Font.PLAIN, 15));
		countEmployeeBtn.setBounds(217, 84, 177, 33);
		countEmployeeBtn.addActionListener(new ButtonListener());

		// Once user clicks the display button, they will be redirected to the
		// appropriate page
		displayEmployeeBtn = new JButton("Display all employees");
		displayEmployeeBtn.setFont(new Font("Tahoma", Font.PLAIN, 15));
		displayEmployeeBtn.setBounds(126, 139, 177, 33);
		displayEmployeeBtn.addActionListener(new ButtonListener());

		// Once user clicks the exit button, they will be exited out of the program
		exitEmployeeBtn = new JButton("Exit");
		exitEmployeeBtn.setFont(new Font("Tahoma", Font.PLAIN, 15));
		exitEmployeeBtn.setBounds(359, 186, 65, 33);
		exitEmployeeBtn.addActionListener(new ButtonListener());

		// Adding all of these components to the panel
		getContentPane().add(mainMenu, BorderLayout.NORTH);
		panel.add(addEmployeeBtn);
		panel.add(dropEmployeeBtn);
		panel.add(updateDateBtn);
		panel.add(countEmployeeBtn);
		panel.add(displayEmployeeBtn);
		panel.add(exitEmployeeBtn);
		getContentPane().add(panel); // This adds the panel to the content frame
	}

	// What class implements the action listener for each button clicked
	private class ButtonListener implements ActionListener {
		// When button is clicked
		public void actionPerformed(ActionEvent e) { // Waits for the action
			String buttonClicked = e.getActionCommand();

			// Searching for String that equals to what button user clicks
			switch (buttonClicked) {
			case "Add an employee": // Adds an employee to the table
				new AddEmployee(myConn);
				break;
			case "Drop an employee": // Drops an employee to the table
				new DropEmployee(myConn);
				break;
			case "Update hiring date": // Updates the hiring date of an employee in the table
				new UpdateHiringDate(myConn);
				break;
			case "Count employees": // Counts the number employees in the table
				try {
					// Prepare the SQL statement to insert a new employee
					stmt = myConn.createStatement();
					myRs = stmt.executeQuery("SELECT COUNT(*) FROM employee");
					
					
					while(myRs.next()) {	// Prints out the # of employees
						results = myRs.getString("COUNT(*)");
					}

					// Close the ResultSet
					myRs.close();
				} catch (SQLException e1) {
				}
				JOptionPane.showMessageDialog(null, "There are " + results + " employees in the database");
				break;
			case "Display all employees": // Displays all the employees in the table
				new DisplayAllEmployees(myConn);
				break;
			case "Exit":
				dispose();
				JOptionPane.showMessageDialog(null, "Program exited");
				try {
					myConn.close();	// Close the database connection
				} catch (SQLException e1) {
				}
				System.exit(0); // Close program
				break;
			default:
				break;
			}
		}
	}

	public static void main(String[] args) {
		// Creating the table from code
		String createTable  = "CREATE TABLE IF NOT EXISTS employee (\nEID int NOT NULL,\n"
				+ "fName varchar(45) DEFAULT NULL,\n"
				+ "lName varchar(45) DEFAULT NULL,\n"
				+ "DateOfJoining date DEFAULT NULL,\n"
				+ "PRIMARY KEY (EID), UNIQUE KEY EID_UNIQUE (EID));";
		Statement stmt;
		
		try {
			// Connect to the database
			myConn = DriverManager.getConnection("jdbc:mysql://localhost:3306/employee", "root", "02171110");
			
			stmt = myConn.createStatement();
			
			// Create a new table if none exists
			stmt.execute(createTable);

		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "Invalid connection, application terminated");
			System.exit(0);
		}
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					EmployeeDatabase frame = new EmployeeDatabase(); // Calling the class in main
					frame.setVisible(true);
				} catch (Exception e) {
				}
			}
		});
	}
}
