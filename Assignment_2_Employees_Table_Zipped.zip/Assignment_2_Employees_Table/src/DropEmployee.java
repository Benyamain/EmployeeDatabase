// Import of packages
import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;
import javax.swing.JTextField;

public class DropEmployee extends JFrame {
	// Declaration of variables
	private JPanel panel;
	private JTextArea employeeListTa; // Where the records will be shown
	private JButton searchBtn, dropBtn;
	private JScrollPane scrollPane; // A scroll pane
	private JScrollBar scrollBar;
	private JLabel dropEmployeeLbl, employeeIdLbl;
	private JTextField employeeIdTf;
	private Connection myConn;
	private ResultSet myRs;
	private PreparedStatement pStmt;
	private final int WINDOW_WIDTH = 300; // Window width
	private final int WINDOW_HEIGHT = 250; // Window height

	public DropEmployee() { // Default constructor

	}

	public DropEmployee(Connection connection) {	// Specific constructor that will be called first to pass the
		// active connection and then this connection will be used in the default
		// constructor
		myConn = connection;

		setTitle("Drop an Employee"); // Setting the title

		// Setting size of the window
		setSize(WINDOW_WIDTH, WINDOW_HEIGHT);

		// We can see the window
		setVisible(true);

		panel = new JPanel(); // Create an instance of the panel

		// Title of the window
		dropEmployeeLbl = new JLabel("Drop Employee");
		dropEmployeeLbl.setHorizontalAlignment(SwingConstants.CENTER);
		dropEmployeeLbl.setFont(new Font("Tahoma", Font.BOLD, 25));

		// Text area that shows what EID matches to what record
		employeeListTa = new JTextArea();
		employeeListTa.setSize(264, 172);
		employeeListTa.setLocation(10, 11);
		employeeListTa.setFont(new Font("Tahoma", Font.PLAIN, 15));
		employeeListTa.setEditable(false); // Do not allow user to type into the text area

		// Add the list to a scroll pane.
		scrollPane = new JScrollPane(employeeListTa);
		scrollBar = new JScrollBar();
		scrollPane.add(scrollBar);
		scrollPane.setSize(264, 77);
		scrollPane.setLocation(10, 47);

		// User has to press this button in order to search the employee database
		searchBtn = new JButton("Search");
		searchBtn.setLocation(113, 9);
		searchBtn.setSize(161, 29);
		searchBtn.setFont(new Font("Tahoma", Font.PLAIN, 15));
		searchBtn.addActionListener(new ActionListener() {
			// When button is clicked
			public void actionPerformed(ActionEvent e) { // Waits for the action
				String buttonClicked = e.getActionCommand();

				if (buttonClicked.equals("Search")) {
					try {
						// Prepare the SQL statement to insert a new employee
						pStmt = myConn.prepareStatement("SELECT * FROM employee WHERE EID = ?");

						// Set the parameters for the SQL statement
						pStmt.setInt(1, Integer.parseInt(employeeIdTf.getText()));

						// Execute the SQL statement
						myRs = pStmt.executeQuery();

						while (myRs.next()) {
							employeeListTa.append(myRs.getInt("EID") + ", " + myRs.getString("fName") + ", "
									+ myRs.getString("lName") + ", " + myRs.getString("DateOfJoining") + "\n");
						}

						// Close the PreparedStatement
						pStmt.close();
					} catch (SQLException e1) {
					} catch (NumberFormatException e2) {
						JOptionPane.showMessageDialog(null, "You must have an Integer value");
						employeeIdTf.setText("");
					}
				}
			}
		});

		// This will drop the employee from the database
		dropBtn = new JButton("Drop");
		dropBtn.setBounds(100, 144, 85, 25);
		dropBtn.setFont(new Font("Tahoma", Font.PLAIN, 15));
		dropBtn.addActionListener(new ActionListener() {
			// When button is clicked
			public void actionPerformed(ActionEvent e) { // Waits for the action
				String buttonClicked = e.getActionCommand();

				if (buttonClicked.equals("Drop")) {
					try {
						// Prepare the SQL statement to insert a new employee
						pStmt = myConn.prepareStatement(
								"DELETE FROM employee WHERE EID = ?");

						// Set the parameters for the SQL statement
						pStmt.setInt(1, Integer.parseInt(employeeIdTf.getText()));

						// Execute the SQL statement
						pStmt.executeUpdate();

						// Close the PreparedStatement
						pStmt.close();
						dispose();
						JOptionPane.showMessageDialog(null, "Employee dropped");
					} catch (SQLException e1) {
						JOptionPane.showMessageDialog(null, "There was an error processing your request");
					} catch (NumberFormatException e2) {
						JOptionPane.showMessageDialog(null, "You must have an Integer value");
					}
					
					// Clearing the input to make sure it is not pre-filled
					employeeIdTf.setText("");
				}
			}
		});
		panel.setLayout(null);

		// Label that serves as the EID
		employeeIdLbl = new JLabel("EID:");
		employeeIdLbl.setFont(new Font("Tahoma", Font.PLAIN, 15));
		employeeIdLbl.setBounds(10, 14, 29, 19);

		// Textfield appropriate to the label
		employeeIdTf = new JTextField(45);
		employeeIdTf.setBounds(48, 11, 55, 25);
		employeeIdTf.setFont(new Font("Tahoma", Font.PLAIN, 15));

		// Adding all of these components to the panel
		getContentPane().add(dropEmployeeLbl, BorderLayout.NORTH);
		panel.add(employeeIdLbl);
		panel.add(employeeIdTf);
		panel.add(searchBtn);
		panel.add(scrollPane);
		panel.add(dropBtn);
		getContentPane().add(panel); // This adds the panel to the content frame
	}
}
