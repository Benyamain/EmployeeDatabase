// Import of packages
import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class AddEmployee extends JFrame {
	// Declaration of variables
	private JPanel panel;
	private JLabel addEmployeeLbl, employeeIdLbl, firstNameLbl, lastNameLbl, employmentDateLbl;
	private JTextField employeeIdTf, firstNameTf, lastNameTf, employmentDateTf;
	private JButton addBtn;
	private Connection myConn;
	private PreparedStatement pStmt;
	private final int WINDOW_WIDTH = 250; // Window width
	private final int WINDOW_HEIGHT = 250; // Window height

	public AddEmployee() { // Default constructor
		
	}

	public AddEmployee(Connection connection) {	// Specific constructor that will be called first to pass the active connection and then
		// this connection will be used in the default constructor
		myConn = connection;
		
		setTitle("Add an employee"); // Setting the title

		// Setting size of the window
		setSize(WINDOW_WIDTH, WINDOW_HEIGHT);

		// We can see the window
		setVisible(true);

		panel = new JPanel(); // Create an instance of the panel

		// Title of the window
		addEmployeeLbl = new JLabel("Add Employee");
		addEmployeeLbl.setHorizontalAlignment(SwingConstants.CENTER);
		addEmployeeLbl.setFont(new Font("Tahoma", Font.BOLD, 25));

		// EID Label
		employeeIdLbl = new JLabel("EID:");
		employeeIdLbl.setBounds(10, 11, 29, 19);
		employeeIdLbl.setFont(new Font("Tahoma", Font.PLAIN, 15));

		// EID Text field
		employeeIdTf = new JTextField(45);
		employeeIdTf.setBounds(89, 8, 135, 25);
		employeeIdTf.setFont(new Font("Tahoma", Font.PLAIN, 15));

		// First Name Label
		firstNameLbl = new JLabel("First Name:");
		firstNameLbl.setBounds(10, 41, 76, 19);
		firstNameLbl.setFont(new Font("Tahoma", Font.PLAIN, 15));

		// First Name Text field
		firstNameTf = new JTextField(45);
		firstNameTf.setBounds(89, 38, 135, 25);
		firstNameTf.setFont(new Font("Tahoma", Font.PLAIN, 15));

		// Last Name Label
		lastNameLbl = new JLabel("Last Name:");
		lastNameLbl.setBounds(10, 71, 76, 19);
		lastNameLbl.setFont(new Font("Tahoma", Font.PLAIN, 15));

		// Last Name Text field
		lastNameTf = new JTextField(45);
		lastNameTf.setBounds(89, 68, 135, 25);
		lastNameTf.setFont(new Font("Tahoma", Font.PLAIN, 15));

		// Employment Date Label
		employmentDateLbl = new JLabel("Date of Employment:");
		employmentDateLbl.setBounds(10, 101, 140, 19);
		employmentDateLbl.setFont(new Font("Tahoma", Font.PLAIN, 15));

		// Employment Date Text field
		employmentDateTf = new JTextField(45);
		employmentDateTf.setBounds(156, 98, 68, 25);
		employmentDateTf.setFont(new Font("Tahoma", Font.PLAIN, 15));

		// Button that serves as the confirmation to add the new employee to the
		// database
		addBtn = new JButton("Add");
		addBtn.setBounds(75, 144, 85, 25);
		addBtn.setFont(new Font("Tahoma", Font.PLAIN, 15));
		addBtn.addActionListener(new ActionListener() {
			// When button is clicked
			public void actionPerformed(ActionEvent e) { // Waits for the action
				String buttonClicked = e.getActionCommand();

				if (buttonClicked.equals("Add")) {
					try {
						// Prepare the SQL statement to insert a new employee
						pStmt = myConn.prepareStatement(
								"INSERT INTO employee (EID, fName, lName, DateOfJoining) VALUES (?, ?, ?, ?)");

						// Set the parameters for the SQL statement
						pStmt.setInt(1, Integer.parseInt(employeeIdTf.getText()));
						pStmt.setString(2, firstNameTf.getText());
						pStmt.setString(3, lastNameTf.getText());
						pStmt.setString(4, employmentDateTf.getText());	// Database will convert it to a date

						// Execute the SQL statement
						pStmt.executeUpdate();

						// Close the PreparedStatement
						pStmt.close();
						dispose();
						JOptionPane.showMessageDialog(null, "Employee added");
					} catch (SQLException e1) {
						JOptionPane.showMessageDialog(null, "No duplicate EIDs, String input cannot be greater than 45 characters, or "
								+ "incorrect date format (yyyy-mm-dd)");
					} catch (NumberFormatException e2) {
						JOptionPane.showMessageDialog(null, "You must have an Integer value");
					}
					
					// Clearing the input to make sure it is not pre-filled
					employeeIdTf.setText("");
					firstNameTf.setText("");
					lastNameTf.setText("");
					employmentDateTf.setText("");
					
				}
			}
		});
		panel.setLayout(null);

		// Adding all of these components to the panel
		getContentPane().add(addEmployeeLbl, BorderLayout.NORTH);
		panel.add(employeeIdLbl);
		panel.add(employeeIdTf);
		panel.add(firstNameLbl);
		panel.add(firstNameTf);
		panel.add(lastNameLbl);
		panel.add(lastNameTf);
		panel.add(employmentDateLbl);
		panel.add(employmentDateTf);
		panel.add(addBtn);
		getContentPane().add(panel); // This adds the panel to the content frame
	}
}
